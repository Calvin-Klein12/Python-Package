from pathlib import Path

def create_project(name):
    project = Path(name)

    project.mkdir()
    (project / "src").mkdir()
    (project / "tests").mkdir()

    (project / 
"README.md").touch
    
    (project / 
".gitignore").touch()
    
    (project / 
"pyproject.toml").touch()

    print(f"{name} created successfully!")