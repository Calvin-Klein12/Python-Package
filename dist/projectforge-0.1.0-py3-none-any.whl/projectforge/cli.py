import argparse
import random
from .generator import create_project

PROJECT_NAMES = [
    "QuickStack",
    "TaskFlow",
    "PyLab",
    "DataNest",
    "Data_tool",
    "Web_app",
    "Python_project",
    "Python_app",
    "Python_tool",
    "Python_service"
    
]

parser = argparse.ArgumentParser(
    description="Create new python structure"
)

parser.add_argument("name", nargs="?")

args = parser.parse_args()

response = ['yes', 'y', 'yep', 'ok', 'of course', 'sure', 'why not']


if args.name:
    name = args.name
else:
    name = input(
        "Enter a project name or press Enter for a suggestion: ").strip()

    if not name:
        name = random.choice(PROJECT_NAMES)
        print(f"Suggested name: {name}")

        preferred_name = input(
        f"Do you like {name}? (yes/no): ").lower().strip()

        if preferred_name not in response:
            while True:
                name = input("Enter your preferred name: ").strip()

                if name:
                    break

                print("Project name cannot be empty.")


create_project(name)
print(f"{name} has been added successfully!")


